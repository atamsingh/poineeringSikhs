$(document).foundation();

$(document).ready(function() {
  $('#fullpage').fullpage({
    anchors: ['intro', 'info'],
    sectionsColor: ['#FFF','#424242'],
    menu: '#menu',
		navigation: true,
		responsiveWidth: 1300
  });
});
